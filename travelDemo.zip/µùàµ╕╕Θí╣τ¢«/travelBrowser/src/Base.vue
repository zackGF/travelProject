<template>

</template>

<script>
  const BASE_URL = 'http://127.0.0.1:5000'; // 设置全局 URL
  export default {
    BASE_URL
  }
</script>

<style scoped>

</style>
